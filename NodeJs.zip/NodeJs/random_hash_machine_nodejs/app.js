const express = require('express');
const sha256 = require('sha256');

const app = express();

// Endpoint #1: Generate a random SHA-256 hash
app.get('/endpoint1', (req, res) => {
  setTimeout(() => {
    const randomString = Math.random().toString(36).substring(2, 34); // Generate a random 32-character string
    const hash = sha256(randomString); // Calculate SHA-256 hash
    res.json({ hash });
  }, 1000); // Respond after 1 second delay
});

// Endpoint #2: Keep requesting a hash from Endpoint #1
app.get('/endpoint2', async (req, res) => {
  let data;
  const response = await fetch('http://localhost:3000/endpoint1'); // Request hash from Endpoint #1
  data = await response.json();
  res.json(data);
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
