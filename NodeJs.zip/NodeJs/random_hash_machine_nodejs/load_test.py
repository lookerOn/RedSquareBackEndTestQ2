import hashlib
import random
import string
import time
from locust import HttpUser, task, between

class RandomHashMachineUser(HttpUser):
    wait_time = between(1, 1)

    @task
    def test_endpoint2(self):
        response = self.client.get("/endpoint2")
        if response.status_code == 200:
            data = response.json()
            print(f"Example of SHA-256 hash:\n{data['hash']}")
            last_char = data["hash"][-1]
            if last_char.isdigit():
                if int(last_char) % 2 == 0:
                    print(f"The last character is `{last_char}`. This is an even number. Does not Pass.")
                else:
                    print(f"The last character is `{last_char}`. This is a number and odd number. Pass!")
            else:
                print(f"The last character is `{last_char}`. This is an alphabet. Does not Pass.")

if __name__ == "__main__":
    RandomHashMachineUser().run()
